import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.*;


/**
 * 
 */

/**
 * @author 13616
 *
 */
public class GUI2014302580385
{
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
				{
					public void run()
					{
						JFrame frame=new PetFrame();
						frame.setTitle("Pet Shop");
						frame.setVisible(true);
						frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					}
				}
				
				);
	}
}

//GUI���
class PetFrame extends JFrame
{
	private static final int WIDTH=600;
	private static final int HEIGHT=700;
	private LogInPanel lonInPanel;
	private ShowPanel showPanel;	
	
	public PetFrame()
	{
		setSize(WIDTH,HEIGHT);
		Toolkit kit=Toolkit.getDefaultToolkit();
		Dimension screenSize=kit.getScreenSize();
		setLocation(screenSize.width/2-WIDTH/2,screenSize.height/2-HEIGHT/2);
		
		lonInPanel=new LogInPanel();
		showPanel=new ShowPanel();
		add(lonInPanel);
		add(showPanel);
		showPanel.setCustomer(lonInPanel.getCustomer());
	
		lonInPanel.setVisible(true);
		showPanel.setVisible(false);
	}
}

//��½���
class LogInPanel extends JPanel
{
	private static final int WIDTH=600;
	private static final int HEIGHT=700;
	private Customer2014302580385 customer;
	private JLabel userLabel;
	private JLabel passwordLabel;
	private JTextField accountNumber;
	private JPasswordField accountPassword;
	private JButton ensureButton;
	private JButton createButton;
	
	public Customer2014302580385 getCustomer()
	{
		return this.customer; 
	}
	public LogInPanel()
	{
		setSize(WIDTH,HEIGHT);
		this.setLayout(null);
		accountNumber=new JTextField(10);
		accountPassword=new JPasswordField(10);	
		userLabel=new JLabel("account:");
		passwordLabel=new JLabel("password:");
		ensureButton=new JButton("ȷ��");		
		createButton=new JButton("ע��");
		customer=new Customer2014302580385();
		ensureButton.addActionListener(new EnsureAction());
		createButton.addActionListener(new CreateAction());
		
		add(userLabel);
		add(passwordLabel);
		add(accountNumber);
		add(accountPassword);	
		add(ensureButton);
		add(createButton);
		
		userLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		userLabel.setBounds(100,100,100,40);
		passwordLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		passwordLabel.setBounds(80,140,140,40);
		accountNumber.setBounds(200,100,200,40);
		accountPassword.setBounds(200,140,200,40);
		ensureButton.setBounds(300,300,100,40);
		createButton.setBounds(180,300,100,40);
		
	}
	
	//ȷ����ť����Ӧ����
	private class EnsureAction extends AbstractAction
	{
		public void actionPerformed(ActionEvent e)
		{
			String account=accountNumber.getText().trim();
			String password=new String(accountPassword.getPassword());
			customer=DataReader2014302580385.LogIn(account, password);
			if(customer!=null)
			{
				LogInPanel.this.setVisible(false);
				LogInPanel.this.getParent().getComponent(1).setVisible(true);
			}
		}		
	}
	
	//ע�ᰴť�ļ�����
	private class CreateAction extends AbstractAction
	{
		private boolean isAdd;
		private CreatePanel createPanel;
		public CreateAction()
		{
			isAdd=false;
			createPanel=new CreatePanel();
			
			
		}
		public void actionPerformed(ActionEvent arg0)
		{
			// TODO �Զ����ɵķ������
			if(isAdd==false)
			{
				LogInPanel.this.getParent().add(createPanel);
				isAdd=true;
			}
			LogInPanel.this.setVisible(false);
			createPanel.setVisible(true);
			
		}
		
		
	}
}


//չʾ���г�����Ϣ�����
class ShowPanel extends JPanel
{
	private static final int WIDTH=600;
	private static final int HEIGHT=700;
	private DataReader2014302580385 dataReader;
	private ArrayList<Pet2014302580385> petList;
	private ArrayList<Good2014302580385> goodList;
	//private JTextField searchText;
	//private JButton searchButton;
	private JButton[] detailButton;
	private ImageIcon[] imageIcon;
	private JButton shopcarButton;
	private Customer2014302580385 customer;
	
	public void setCustomer(Customer2014302580385 customer)
	{
		this.customer=customer;
		this.customer.getShopcar().setGood(goodList);
	}
	
	public ShowPanel()
	{
		setSize(WIDTH,HEIGHT);
		this.setLayout(null);
		
		dataReader=new DataReader2014302580385();
		petList=dataReader.read();		
		goodList=new ArrayList<Good2014302580385>();
		detailButton=new JButton[12];
		imageIcon=new ImageIcon[12];
		customer=new Customer2014302580385();
		
		for(int i=0;i<12;i++)
		{
			Good2014302580385 temp=new Good2014302580385();
			temp.setPrice(i+1);
			temp.setPet(petList.get(i));
			goodList.add(temp);
		}
		for(int i=0;i<12;i++)
		{	
			//��ȡ���ݿ⣬Ȼ���ʼ����ť			
			String tempName=petList.get(i).getName();
			java.net.URL imgURL = ShowPanel.class.getResource("/image/"+tempName+".jpg");
			imageIcon[i]=new ImageIcon(imgURL);
			detailButton[i]=new JButton(imageIcon[i]);
			detailButton[i].addActionListener(new DetailAction(goodList.get(i)));
			add(detailButton[i]);			
			detailButton[i].setBounds((i%3)*200+50,(i/3)*130+15,100,100);	
		}
		
		shopcarButton=new JButton("�鿴���ﳵ");
		shopcarButton.addActionListener(new ShopcarAction());
		add(shopcarButton);
		shopcarButton.setBounds(WIDTH/2-100/2,600,100,40);
		
		/*searchText=new JTextField("������Ҫ��ѯ�ĳ�����");
		searchButton=new JButton("��ѯ");
		searchButton.addActionListener(new SearchAction());
		searchText.addFocusListener(new FocusListener()
		{

			@Override
			public void focusGained(FocusEvent arg0)
			{
				// TODO �Զ����ɵķ������
				searchText.setText("");
			}

			@Override
			public void focusLost(FocusEvent arg0)
			{
				// TODO �Զ����ɵķ������
				if(searchText.getText().equals(""))
					searchText.setText("������Ҫ��ѯ�ĳ�����");
			}
			
		});
		add(searchText);
		add(searchButton);
		searchText.setBounds(100, 550, 200, 40);
		searchButton.setBounds(350,550,100,40);*/
	}
	
	//�鿴������ϸ��Ϣ�İ�ť�ļ�����
	private class DetailAction extends AbstractAction
	{
		private DetailPanel detailPanel;
		private boolean isAdd;
		public DetailAction(Good2014302580385 good)
		{
			isAdd=false;
			detailPanel=new DetailPanel(good);						
		}
		public void actionPerformed(ActionEvent arg0)
		{
			// TODO �Զ����ɵķ������
			ShowPanel.this.setVisible(false);
			if(isAdd==false)
			{
				ShowPanel.this.getParent().add(detailPanel);
				isAdd=true;
			}
			detailPanel.setVisible(true);
			
		}
		
		
	}
	
	//�鿴���ﳵ�ļ�����
	private class ShopcarAction extends AbstractAction
	{
		private boolean isAdd;
		private ShopcarPanel shopcarPanel;
		public ShopcarAction()
		{
			shopcarPanel=new ShopcarPanel(goodList);//customer.getShopcar().getGood()
			isAdd=false;
		}
		public void actionPerformed(ActionEvent arg0)
		{
			// TODO �Զ����ɵķ������
			ShowPanel.this.setVisible(false);
			if(isAdd==false)
			{
				ShowPanel.this.getParent().add(shopcarPanel);
				isAdd=true;
			}
			shopcarPanel.Refresh();
			shopcarPanel.setVisible(true);
			
		}
		
	}
	
	//��ѯ��ť�ļ�����
	/*private class SearchAction extends AbstractAction
	{
		
		@Override
		public void actionPerformed(ActionEvent arg0)
		{
			// TODO �Զ����ɵķ������
			
		}
		
	}*/
}


//չʾ������ϸ�����
class DetailPanel extends JPanel
{
	private static final int WIDTH=600;
	private static final int HEIGHT=700;
	private Good2014302580385 good;
	private Pet2014302580385 pet; 
	private JLabel pictureLabel;
	private JLabel idLabel;
	private JLabel nameLabel;
	private JLabel eatLabel;
	private JLabel drinkLabel;
	private JLabel liveLabel;
	private JLabel hobbyLabel;
	private JLabel priceLabel;
	
	private JButton backButton;
	private JTextField numberText;
	private JButton purchaseButton;
	public DetailPanel(Good2014302580385 good)
	{
		setSize(WIDTH,HEIGHT);
		this.setLayout(null);
		
		this.good=good;
		this.pet=this.good.getPet();
		java.net.URL imgURL = DetailPanel.class.getResource("/image/"+this.pet.getName()+".jpg");
		pictureLabel=new JLabel(new ImageIcon(imgURL));
		idLabel=new JLabel("id:"+String.valueOf(this.pet.getId()));
		nameLabel=new JLabel("name:"+this.pet.getName());
		eatLabel=new JLabel("eat:"+this.pet.getEat());
		drinkLabel=new JLabel("drink:"+this.pet.getDrink());
		liveLabel=new JLabel("live:"+this.pet.getLive());
		hobbyLabel=new JLabel("hobby:"+this.pet.getHobby());
		priceLabel=new JLabel("price:"+this.good.getPrice());
		backButton=new JButton("������һ��");
		numberText=new JTextField("��������ֵ");
		purchaseButton=new JButton("����");
		
		
		add(pictureLabel);
		add(idLabel);
		add(nameLabel);
		add(eatLabel);
		add(drinkLabel);
		add(liveLabel);
		add(hobbyLabel);
		add(priceLabel);
		add(backButton);
		add(numberText);
		add(purchaseButton);
		
		backButton.addActionListener(new BackAction());
		purchaseButton.addActionListener(new PurchaseAction());
		numberText.addFocusListener(new FocusListener()
		{

			@Override
			public void focusGained(FocusEvent arg0)
			{
				// TODO �Զ����ɵķ������
				numberText.setText("");
			}

			@Override
			public void focusLost(FocusEvent arg0)
			{
				// TODO �Զ����ɵķ������
				if(numberText.getText().equals(""))
				numberText.setText("�����빺����ֵ");		
			}
			
		});
		
		idLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		nameLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		eatLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		drinkLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		liveLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		hobbyLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		priceLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		
		pictureLabel.setBounds(100, 50, 100, 100);
		idLabel.setBounds(100,160,500,30);
		nameLabel.setBounds(100,200,500,30);
		eatLabel.setBounds(100,240,500,30);
		drinkLabel.setBounds(100,280,500,30);
		liveLabel.setBounds(100,320,500,30);
		hobbyLabel.setBounds(100,360,500,30);
		priceLabel.setBounds(100,400,500,30);
		numberText.setBounds(200,500,100,40);
		purchaseButton.setBounds(350,500,100,40);
		backButton.setBounds(WIDTH/2-100/2,600,100,40);
		
		
	}
	
	//���ذ�ť�ļ�����
	private class BackAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			// TODO �Զ����ɵķ������
			numberText.setText("�����빺����ֵ");
			DetailPanel.this.setVisible(false);
			DetailPanel.this.getParent().getComponent(1).setVisible(true);
		}
		
	}
	
	//����ť�ļ�����
	private class PurchaseAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			// TODO �Զ����ɵķ������
			String num=numberText.getText().trim();
			Pattern numPattern=Pattern.compile("[0-9]*");
			Matcher numMatcher=numPattern.matcher(num);
			if(numMatcher.matches()==false)
			{
				JOptionPane.showMessageDialog( null,"��������Ч������" ,
						  "Error", JOptionPane.PLAIN_MESSAGE );
				return;
			}
			good.setNumber(Integer.valueOf(num)+good.getNumber());
			
			JOptionPane.showMessageDialog( null,"�Ѽ��빺�ﳵ" ,
					  "Error", JOptionPane.PLAIN_MESSAGE );
			
		}
		
	}
}


//չʾ���ﳵ�����
class ShopcarPanel extends JPanel
{
	private static final int WIDTH=600;
	private static final int HEIGHT=700;
	private Shopcar2014302580385 shopcar;
	private ArrayList<JLabel> nameLabel;
	private ArrayList<JLabel> numberLabel;
	private ArrayList<JButton> deleteButton;
	private ArrayList<JButton> addButton;
	private ArrayList<JButton> reduceButton;
	private ArrayList<Rectangle> nameRec;
	private ArrayList<Rectangle> numberRec;
	private ArrayList<Rectangle> deleteRec;
	private ArrayList<Rectangle> addRec;
	private ArrayList<Rectangle> reduceRec;
	private JButton purchaseButton;
	private JButton backButton;
	
	//���¹��ﳵ��Ϣ
	public void Refresh()
	{
		int goodNumber=0;
		for(int i=0;i<shopcar.getGood().size();i++)
		{
			if(shopcar.getGood().get(i).getNumber()>0)
			{
				numberLabel.get(i).setText("����:"+String.valueOf(shopcar.getGood().get(i).getNumber()));
				nameLabel.get(i).setBounds(nameRec.get(goodNumber));
				numberLabel.get(i).setBounds(numberRec.get(goodNumber));
				deleteButton.get(i).setBounds(deleteRec.get(goodNumber));
				addButton.get(i).setBounds(addRec.get(goodNumber));
				reduceButton.get(i).setBounds(reduceRec.get(goodNumber));
				
				nameLabel.get(i).setVisible(true);
				numberLabel.get(i).setVisible(true);
				deleteButton.get(i).setVisible(true);
				addButton.get(i).setVisible(true);
				reduceButton.get(i).setVisible(true);
				goodNumber++;
			}else
			{
				nameLabel.get(i).setVisible(false);
				numberLabel.get(i).setVisible(false);
				deleteButton.get(i).setVisible(false);
				addButton.get(i).setVisible(false);
				reduceButton.get(i).setVisible(false);
			}
		}
		
	}
	
	
	public ShopcarPanel(ArrayList<Good2014302580385> goodList)
	{
		setSize(WIDTH,HEIGHT);
		this.setLayout(null);
		
		shopcar=new Shopcar2014302580385();
		shopcar.setGood(goodList);
		
		nameLabel=new ArrayList<JLabel>();
		numberLabel =new ArrayList<JLabel>();
		deleteButton=new ArrayList<JButton>();		
		nameRec=new ArrayList<Rectangle>();
		numberRec=new ArrayList<Rectangle>();
		deleteRec=new ArrayList<Rectangle>();
		purchaseButton=new JButton("ȷ������");
		backButton=new JButton("��������");
		addButton=new ArrayList<JButton>();
		reduceButton=new ArrayList<JButton>();
		addRec=new ArrayList<Rectangle>();
		reduceRec=new ArrayList<Rectangle>();

		for(int i=0;i<shopcar.getGood().size();i++)
		{
			nameLabel.add(new JLabel("��Ʒ��:"+shopcar.getGood().get(i).getPet().getName()));
			numberLabel.add(new JLabel("����:"+String.valueOf(shopcar.getGood().get(i).getNumber())));
			deleteButton.add(new JButton("ɾ��"));
			addButton.add(new JButton("+"));
			reduceButton.add(new JButton("-"));
			
			deleteButton.get(i).addActionListener(new DeleteAction(i));
			addButton.get(i).addActionListener(new AddAction(i));
			reduceButton.get(i).addActionListener(new ReduceAction(i));
			
			add(nameLabel.get(i));
			add(numberLabel.get(i));
			add(deleteButton.get(i));
			add(addButton.get(i));
			add(reduceButton.get(i));
			
			nameRec.add(new Rectangle(50,i*50,200,50));
			numberRec.add(new Rectangle(250,i*50,100,50));
			deleteRec.add(new Rectangle(350,i*50+10,100,30));
			addRec.add(new Rectangle(480,i*50+10,50,30));
			reduceRec.add(new Rectangle(530,i*50+10,50,30));
	
		}
		add(backButton);
		add(purchaseButton);
		backButton.addActionListener(new BackAction());
		purchaseButton.addActionListener(new PurchaseAction());
		
		backButton.setBounds(100,600,100,50);
		purchaseButton.setBounds(300,600,100,50);
		
	}
	
	//ɾ����ť�ļ�����
	private class DeleteAction extends AbstractAction
	{

		private int id;
		public DeleteAction(int id)
		{
			this.id=id;
		}
		public void actionPerformed(ActionEvent e)
		{
			// TODO �Զ����ɵķ������
			shopcar.getGood().get(id).setNumber(0);
			Refresh();
			ShopcarPanel.this.repaint();
		}
		
	}
	
	//���ذ�ť�ļ�����
	private class BackAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			// TODO �Զ����ɵķ������
			ShopcarPanel.this.setVisible(false);
			ShopcarPanel.this.getParent().getComponent(1).setVisible(true);
			
		}
		
	}
	
	//����ť�ļ�����
	private class PurchaseAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			// TODO �Զ����ɵķ������
			int all=0;
			for(int i=0;i<12;i++)
			{
				all+=shopcar.getGood().get(i).getNumber()*shopcar.getGood().get(i).getPrice();	
			}
			JOptionPane.showMessageDialog( null,"��"+String.valueOf(all)+"Ԫת����֧����!",
					  "Error", JOptionPane.PLAIN_MESSAGE );
			for(int i=0;i<12;i++)
			{
				shopcar.getGood().get(i).setNumber(0);
				Refresh();
			}
		}
		
	}
	private class AddAction extends AbstractAction
	{

		private int id;
		public AddAction(int id)
		{
			this.id=id;
		}
		public void actionPerformed(ActionEvent e)
		{
			// TODO �Զ����ɵķ������
			shopcar.getGood().get(id).setNumber(shopcar.getGood().get(id).getNumber()+1);
			Refresh();
			ShopcarPanel.this.repaint();
		}
		
	}
	private class ReduceAction extends AbstractAction
	{

		private int id;
		public ReduceAction(int id)
		{
			this.id=id;
		}
		public void actionPerformed(ActionEvent e)
		{
			// TODO �Զ����ɵķ������
			shopcar.getGood().get(id).setNumber(shopcar.getGood().get(id).getNumber()-1);
			Refresh();
			ShopcarPanel.this.repaint();
		}
		
	}
}

//ע�����
class CreatePanel extends JPanel
{
	private static final int WIDTH=600;
	private static final int HEIGHT=700;
	private JLabel registerLabel;
	private JLabel accountLabel;
	private JLabel passwordLabel;
	private JLabel nameLabel;
	private JLabel sexLabel;
	private JLabel phoneLabel;
	private JLabel emailLabel;
	
	private JTextField accountText;
	private JTextField passwordText;
	private JTextField nameText;
	private JTextField sexText;
	private JTextField phoneText;
	private JTextField emailText;
	
	private JButton backButton;
	private JButton registerButton;
	public CreatePanel()
	{
		setSize(WIDTH,HEIGHT);
		this.setLayout(null);
		
		registerLabel=new JLabel("ע��");
		accountLabel=new JLabel("account:");
		passwordLabel=new JLabel("password:");
		nameLabel=new JLabel("name:");
		sexLabel=new JLabel("sex:");
		phoneLabel=new JLabel("phone:");
		emailLabel=new JLabel("email:");
		
		accountText=new JTextField();
		passwordText=new JTextField();
		nameText=new JTextField();
		sexText=new JTextField();
		phoneText=new JTextField();
		emailText=new JTextField();
		
		backButton=new JButton("����");
		registerButton=new JButton("ע��");
		
		backButton.addActionListener(new BackAction());
		registerButton.addActionListener(new RegisterAction());
		
		add(registerLabel);
		add(accountLabel);
		add(passwordLabel);
		add(nameLabel);
		add(sexLabel);
		add(phoneLabel);
		add(emailLabel);
		add(accountText);
		add(passwordText);
		add(nameText);
		add(sexText);
		add(phoneText);
		add(emailText);
		add(backButton);
		add(registerButton);
		
		registerLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		accountLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		passwordLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		nameLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		sexLabel.setFont(new java.awt.Font("Dialog", 0, 25));	
		phoneLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		emailLabel.setFont(new java.awt.Font("Dialog", 0, 25));
		
		registerLabel.setBounds(WIDTH/2-50,20,100,30);
		accountLabel.setBounds(100,50,100,30);
		accountText.setBounds(200, 50, 200, 30);
		passwordLabel.setBounds(80,100,120,30);
		passwordText.setBounds(200, 100, 200, 30);
		nameLabel.setBounds(120,150,100,30);
		nameText.setBounds(200, 150, 200, 30);
		sexLabel.setBounds(140,200,100,30);
		sexText.setBounds(200, 200, 200, 30);
		phoneLabel.setBounds(110,250,100,30);
		phoneText.setBounds(200,250,200,30);
		emailLabel.setBounds(120,300,100,30);
		emailText.setBounds(200, 300, 200, 30);
		
		backButton.setBounds(150,350,100,50);
		registerButton.setBounds(300,350,100,50);
		
	}
	private class BackAction  extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent arg0)
		{
			// TODO �Զ����ɵķ������
			CreatePanel.this.setVisible(false);
			CreatePanel.this.getParent().getComponent(0).setVisible(true);
		}
	}
	private class RegisterAction extends AbstractAction
	{

		@Override
		public void actionPerformed(ActionEvent e)
		{
			// TODO �Զ����ɵķ������
			DataReader2014302580385.Register(accountText.getText().trim(), passwordText.getText().trim(), nameText.getText().trim(), sexText.getText().trim(), phoneText.getText().trim(), emailText.getText().trim());
		}
		
	}	
}