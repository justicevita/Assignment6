import java.util.ArrayList;

public class Shopcar2014302580385
{
	private ArrayList<Good2014302580385> good;
	public Shopcar2014302580385()
	{
		good=new ArrayList<Good2014302580385>();
	}

	public ArrayList<Good2014302580385> getGood()
	{
		return good;
	}

	public void setGood(ArrayList<Good2014302580385> good)
	{
		this.good = good;
	} 
}
