
public class Good2014302580385
{
	private Pet2014302580385 pet;
	private int number;
	private double price;
	public Good2014302580385()
	{
		number=0;
	}
	public Pet2014302580385 getPet()
	{
		return pet;
	}
	public void setPet(Pet2014302580385 pet)
	{
		this.pet = pet;
	}
	public int getNumber()
	{
		return number;
	}
	public void setNumber(int number)
	{
		this.number = number;
	}
	public double getPrice()
	{
		return price;
	}
	public void setPrice(double price)
	{
		this.price = price;
	}
}
