import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class DataReader2014302580385
{
	private static String url="jdbc:mysql://127.0.0.1:3306/my_shcema?user=root&password=123456";
	private static String petSql="SELECT * FROM 2014302580385_pet;";
	private static String userSql="SELECT * FROM 2014302580385_user;";
	public static Connection getConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url);
			System.out.println("ע�������ɹ�");
			return conn;
		} catch (ClassNotFoundException | SQLException e)
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			System.out.println("ע������ʧ��");
			return null;
		}
	
	}
	//��½����
	public static Customer2014302580385 LogIn(String account,String password)
	{
		Customer2014302580385 customer=new Customer2014302580385();
		boolean isExist=false;
		Connection conn=getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			ps=conn.prepareStatement(userSql);
			rs=ps.executeQuery();
			while(rs.next())
			{
				//��������ݿ��е��˻����˺�����ƥ�䣬�򷵻��˻���Ϣ
				if(account.equals(rs.getString(1))&&password.equals(rs.getString(2)))
				{
					isExist=true;
					customer.setAccount(rs.getString(1));
					customer.setName(rs.getString(3));
					customer.setSex(rs.getString(4));
					customer.setPhone(rs.getString(5));
					customer.setEmail(rs.getString(6));
				}
			}
		} catch (SQLException e)
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}finally
		{
			try
			{
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e)
			{
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			
			
		}
		if(isExist==true)
			return customer;
		else
		{
			JOptionPane.showMessageDialog( null,"��������ȷ���˻�����",
					  "Error", JOptionPane.PLAIN_MESSAGE );
			return null;
			
		}
	}
	
	
	//ע�����
	public static boolean Register(String account,String password,String name,String sex,String phone,String email)
	{
		//������ֿ�ֵ
		if(account.equals("")||password.equals("")||name.equals("")||sex.equals("")||phone.equals("")||email.equals(""))
		{
			JOptionPane.showMessageDialog( null,"��������������Ϣ",
					  "Error", JOptionPane.PLAIN_MESSAGE );
			return false;
		}
		String registerSql="insert into 2014302580385_user(account,password,name,sex,phone,email) values('"+account+"','"+password+"','"+name+"','"+sex+"','"+phone+"','"+email+"');";
;		Connection conn=getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		//���������ظ�
		try
		{
			ps=conn.prepareStatement(userSql);
			rs=ps.executeQuery();
			while(rs.next())
			{	
				if(account.equals(rs.getString(1)))
				{
					JOptionPane.showMessageDialog( null,"���˻��ѱ�ע��",
							  "Error", JOptionPane.PLAIN_MESSAGE );
					return false;
				}
			}
		} catch (SQLException e)
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}finally
		{
			try
			{
				rs.close();
				ps.close();
			} catch (SQLException e)
			{
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}			
		}
		
		
		try
		{
			ps=conn.prepareStatement(registerSql);
			ps.executeUpdate(registerSql);	
		} catch (SQLException e)
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
				conn.close();
			} catch (SQLException e)
			{
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}			
		}
		JOptionPane.showMessageDialog( null,"�ɹ�ע��",
				  "Congratulation", JOptionPane.PLAIN_MESSAGE );
		return true;
		
	}
	
	//��ȡ������Ϣ
	public ArrayList<Pet2014302580385> read()
	{
		ArrayList<Pet2014302580385> petList=new ArrayList<Pet2014302580385>();
		Connection conn=getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			ps=conn.prepareStatement(petSql);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Pet2014302580385 temp=new Pet2014302580385();
				temp.setId(Integer.valueOf(rs.getInt(1)));
				temp.setName(rs.getString(2).toLowerCase());
				temp.setEat(rs.getString(3).toLowerCase());
				temp.setDrink(rs.getString(4).toLowerCase());
				temp.setLive(rs.getString(5).toLowerCase());
				temp.setHobby(rs.getString(6).toLowerCase());
				petList.add(temp);				
			}
			return petList;
			
		} catch (SQLException e)
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			return null;
		}finally
		{
			try
			{
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e)
			{
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			
			
		}
	}
}
